module.exports = { reactStrictMode: true };
