// POST /api/paystack/initialize
// Body: { email, amount, category, quantity, blhCode, farmerId, customerName }
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const { email, amount, category, quantity, blhCode, farmerId, customerName } = req.body;

  // Map category to split code
  const splitMap = {
    "Postfries Fingerlings <3cm": "SPL_POSTFRIES_12",
    "Standard fingerlings >4cm": "SPL_STANDARD_12",
    "Juveniles >6cm": "SPL_JUVENILE_12",
    "Growout Table Size": "SPL_GROWOUT_12",
    "Ebook": "SPL_EBOOK_50",
    "Feed": "SPL_FEED_15"
  };
  const split_code = splitMap[category] || "SPL_POSTFRIES_12";

  const secret = process.env.PAYSTACK_SECRET_KEY;
  const response = await fetch("https://api.paystack.co/transaction/initialize", {
    method: "POST",
    headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      email,
      amount: amount * 100,
      split_code,
      metadata: {
        blh_code: blhCode,
        category,
        quantity,
        farmer_id: farmerId,
        customer_name: customerName,
        hub_opay: "9161418039",
        paystack_account: "Agricsquareservices@gmail.com"
      },
      callback_url: `https://${req.headers.host}/payment/success?blh=${blhCode}`
    })
  });
  const data = await response.json();
  if (!data.status) return res.status(400).json(data);
  return res.status(200).json({ authorization_url: data.data.authorization_url, reference: data.data.reference, split_code });
}