// utils/paystack.js
// Better Life Hub - Paystack Split Initialization for Opay 9161418039 + Agricsquareservices@gmail.com

const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY; // sk_live_xxx - Agricsquareservices@gmail.com
const PAYSTACK_PUBLIC = process.env.NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY; // pk_live_xxx

// Size-based pricing (your portal pricing)
const PRICING = {
  "Postfries Fingerlings <3cm": { perPc: 25, market: "N20-30", split: "SPL_POSTFRIES_12", affiliate: 12 },
  "Standard fingerlings >4cm": { perPc: 35, market: "N30-45", split: "SPL_STANDARD_12", affiliate: 12 },
  "Juveniles >6cm": { perPc: 60, market: "N50-75", split: "SPL_JUVENILE_12", affiliate: 12 },
  "Growout Table Size": { perFish: 2500, perKg: 2800, weights: { "500g": 1800, "800g": 2500, "1kg": 3000, "1.2kg": 3500, "1.5kg": 4200 }, split: "SPL_GROWOUT_12", affiliate: 12 },
  "Broodstock": { perPair: 25000, split: "SPL_BROODSTOCK_12", affiliate: 12 },
  "Ebook": { price: 10000, split: "SPL_EBOOK_50", affiliate: 50 },
  "Feed": { perBag: 15000, split: "SPL_FEED_15", affiliate: 15 }
};

// 1. Create Farmer Subaccount (when farmer registers with Opay 9161418039 or other bank)
export async function createFarmerSubaccount({ farmName, accountNumber, bankCode, email, phone }) {
  const res = await fetch("https://api.paystack.co/subaccount", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${PAYSTACK_SECRET}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      business_name: farmName,
      settlement_bank: bankCode, // 999992 for Opay 9161418039, 058 GTB, 044 Access etc
      account_number: accountNumber, // e.g. 9161418039 for Hub, farmer's own for farmer
      percentage_charge: 8, // Hub keeps 8%
      description: `Catfish Farm - ${farmName}`,
      primary_contact_email: email,
      primary_contact_name: farmName,
      primary_contact_phone: phone,
      settlement_schedule: "auto" // T+1 to Opay/bank
    })
  });
  const data = await res.json();
  // Returns ACCT_xxx - save to DB as farmer.subaccount_code
  return data.data.subaccount_code;
}

// 2. Create Affiliate Subaccount (when affiliate registers with BLH042)
export async function createAffiliateSubaccount({ blhCode, fullName, accountNumber, bankCode, email }) {
  const res = await fetch("https://api.paystack.co/subaccount", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${PAYSTACK_SECRET}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      business_name: `${blhCode} - ${fullName}`,
      settlement_bank: bankCode,
      account_number: accountNumber,
      percentage_charge: 0, // Controlled by split code
      description: `Affiliate ${blhCode}`,
      primary_contact_email: email,
      primary_contact_name: fullName,
      settlement_schedule: "auto"
    })
  });
  const data = await res.json();
  return data.data.subaccount_code; // ACCT_AFFILIATE_xxx
}

// 3. Create Split Codes (One-time setup for Agricsquareservices@gmail.com account)
export async function setupSplitCodes() {
  const splits = [
    { name: "Better Life Hub - Postfries 12%", type: "percentage", currency: "NGN", subaccounts: [], bearer_type: "all-proportional" },
    { name: "Better Life Hub - Standard 12%", type: "percentage", currency: "NGN", subaccounts: [], bearer_type: "all-proportional" },
    { name: "Better Life Hub - Juvenile 12%", type: "percentage", currency: "NGN", subaccounts: [], bearer_type: "all-proportional" },
    { name: "Better Life Hub - Growout 12%", type: "percentage", currency: "NGN", subaccounts: [], bearer_type: "all-proportional" },
    { name: "Better Life Hub - Ebook 50%", type: "percentage", currency: "NGN", subaccounts: [], bearer_type: "all-proportional" }
  ];

  // After creating farmer + affiliate subaccounts, create splits with their ACCT codes
  // Example: POST /split with subaccounts: [{subaccount: ACCT_FARMER, share: 80}, {subaccount: ACCT_AFFILIATE, share: 12}]
  // Hub gets remaining 8% (or 20% for ebooks) to Opay 9161418039
}

// 4. Initialize Paystack Transaction with Split + BLH Code tracking
export async function initializePaystackPayment({ email, amount, category, quantity, blhCode, farmerSubaccount, affiliateSubaccount, splitCode, customerName }) {
  const amountKobo = amount * 100; // N25,000 -> 2500000 kobo
  
  const res = await fetch("https://api.paystack.co/transaction/initialize", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${PAYSTACK_SECRET}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      email: email,
      amount: amountKobo,
      split_code: splitCode, // SPL_xxx - 80/12/8 split
      // OR for dynamic: subaccount + transaction_charge if not using split
      // subaccount: farmerSubaccount,
      // transaction_charge: Math.round(amount * 0.08 * 100), // Hub fee
      metadata: {
        blh_code: blhCode, // BLH042 - affiliate tracking
        category: category, // Postfries <3cm etc
        quantity: quantity,
        product: `${category} - ${quantity}pcs`,
        farmer_id: farmerSubaccount,
        customer_name: customerName,
        hub_opay: "9161418039", // Your new Opay - for reference
        paystack_account: "Agricsquareservices@gmail.com",
        custom_fields: [
          { display_name: "Affiliate Code", variable_name: "affiliate_code", value: blhCode },
          { display_name: "Farm", variable_name: "farm", value: farmerSubaccount },
          { display_name: "Hub Opay", variable_name: "hub_opay", value: "9161418039" }
        ]
      },
      callback_url: `https://betterlifehub.com/payment/success?ref=${blhCode}&amount=${amount}`
    })
  });
  const data = await res.json();
  return data.data.authorization_url; // Redirect customer here to pay
}

// Frontend: Paystack Inline popup
export function payWithPaystack({ email, amount, blhCode, splitCode, onSuccess }) {
  const handler = window.PaystackPop.setup({
    key: PAYSTACK_PUBLIC, // pk_live_xxx for Agricsquareservices@gmail.com
    email: email,
    amount: amount * 100,
    currency: "NGN",
    ref: `BLH-${blhCode}-${Date.now()}`,
    split_code: splitCode,
    metadata: {
      blh_code: blhCode,
      hub_opay: "9161418039",
      custom_fields: [{ display_name: "Affiliate", variable_name: "affiliate", value: blhCode }]
    },
    callback: function(response) {
      // Verify on backend via webhook
      onSuccess(response.reference);
      // Show success: Order ID, commission split to Opay 9161418039
    },
    onClose: function() {
      console.log("Payment closed");
    }
  });
  handler.openIframe();
}
