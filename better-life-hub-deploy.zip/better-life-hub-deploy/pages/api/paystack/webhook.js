// pages/api/paystack/webhook.js
// Better Life Hub - Paystack Webhook for Agricsquareservices@gmail.com + Opay 9161418039
// Deploy to Vercel / Next.js

import crypto from "crypto";

const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY; // sk_live_xxx from dashboard.paystack.com - Agricsquareservices@gmail.com account
const GOOGLE_SHEET_WEBHOOK = process.env.SHEET_WEBHOOK_URL; // Optional: Make.com or SheetDB

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).send("Method Not Allowed");

  // 1. Verify Paystack signature
  const hash = crypto.createHmac("sha512", PAYSTACK_SECRET).update(JSON.stringify(req.body)).digest("hex");
  if (hash !== req.headers["x-paystack-signature"]) {
    return res.status(401).send("Invalid signature");
  }

  const event = req.body;
  console.log("Paystack Event:", event.event);

  if (event.event === "charge.success") {
    const data = event.data;
    const amount = data.amount / 100; // kobo to naira
    const email = data.customer.email;
    const ref = data.reference;
    const metadata = data.metadata || {};
    
    const blhCode = metadata.blh_code || "BLH000"; // e.g. BLH042 from ?ref=BLH042
    const product = metadata.product || "Catfish Product";
    const farmerId = metadata.farmer_id || "VND-001";
    const category = metadata.category || "Postfries Fingerlings <3cm";
    const quantity = metadata.quantity || 1000;
    const splitCode = data.split_code; // e.g. SPL_POSTFRIES_12

    // 2. Calculate split based on size-based pricing
    let farmerShare, affiliateShare, hubShare;
    if (category.includes("Postfries") || category.includes("Standard") || category.includes("Juveniles") || category.includes("Growout")) {
      farmerShare = amount * 0.80;
      affiliateShare = amount * 0.12;
      hubShare = amount * 0.08;
    } else if (category.includes("Ebook")) {
      farmerShare = amount * 0.30;
      affiliateShare = amount * 0.50;
      hubShare = amount * 0.20;
    } else {
      farmerShare = amount * 0.80;
      affiliateShare = amount * 0.12;
      hubShare = amount * 0.08;
    }

    // 3. Create Order in your DB / Google Sheet
    const order = {
      order_id: `BLH-ORD-${Date.now().toString().slice(-6)}`,
      paystack_ref: ref,
      split_code: splitCode,
      customer_email: email,
      customer_name: data.customer.first_name || metadata.customer_name,
      product: product,
      category: category,
      quantity: quantity,
      amount_paid: amount,
      blh_code: blhCode,
      farmer_id: farmerId,
      farmer_share: farmerShare,
      affiliate_share: affiliateShare,
      hub_share: hubShare,
      hub_opay: "9161418039", // Your new Opay - hub fee settles here via Paystack settlement
      payment_method: "Paystack",
      split_status: "Split Successful - Paid Instantly",
      status: "Paid - Awaiting Delivery",
      date: new Date().toISOString(),
      paystack_account: "Agricsquareservices@gmail.com"
    };

    console.log("New Order:", order);

    // 4. Save to Google Sheet (via Make.com / Zapier / SheetDB)
    if (GOOGLE_SHEET_WEBHOOK) {
      await fetch(GOOGLE_SHEET_WEBHOOK, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(order)
      });
    }

    // 5. Trigger WhatsApp Alerts (via WhatsApp Cloud API or Termii)
    // Affiliate alert: You earned N3,000 instantly
    const affiliateMsg = `🎉 Better Life Hub - You earned N${affiliateShare.toLocaleString()} instantly! Customer paid N${amount.toLocaleString()} for ${product}. Paystack Ref: ${ref}. Your commission split to your bank. Order: ${order.order_id} - Ref: ${blhCode}`;
    
    // Farmer alert
    const farmerMsg = `🐟 New Order ${order.order_id} - ${product} Qty ${quantity} - N${amount.toLocaleString()} paid via Paystack. Your share N${farmerShare.toLocaleString()} sent to your account instantly. Customer: ${order.customer_name}. Hub Opay 9161418039 received fee.`;
    
    // Customer alert
    const customerMsg = `✅ Payment confirmed N${amount.toLocaleString()} for ${product}. Order ${order.order_id} - Paystack Ref ${ref}. Delivery in 24-48hrs. Hub Opay 9161418039. Better Life Hub.`;

    // Call WhatsApp API (example with Termii)
    // await sendWhatsApp(affiliatePhone, affiliateMsg);
    // await sendWhatsApp(farmerPhone, farmerMsg);
    // await sendWhatsApp(customerPhone, customerMsg);

    // 6. For Opay 9161418039 - Hub fee already settles to Opay via Paystack settlement (T+1 auto)
    // No manual action needed for Paystack orders

    return res.status(200).send({ success: true, order });
  }

  res.status(200).send("Event received");
}

// Helper - Send WhatsApp via Termii / WhatsApp Cloud API
async function sendWhatsApp(phone, message) {
  // Replace with your Termii API key or WhatsApp Cloud API
  // const res = await fetch("https://api.ng.termii.com/api/sms/send", {
  //   method: "POST",
  //   headers: { "Content-Type": "application/json" },
  //   body: JSON.stringify({
  //     to: phone,
  //     from: "BetterLifeHub",
  //     sms: message,
  //     type: "plain",
  //     channel: "whatsapp"
  //   })
  // });
  // return res.json();
  console.log(`WhatsApp to ${phone}: ${message}`);
}
