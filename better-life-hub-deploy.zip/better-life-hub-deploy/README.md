# Better Life Hub - Fully Automated Portal
Paystack: Agricsquareservices@gmail.com
Opay: 9161418039 (replaces 9137837008)

Size-Based Pricing + 3-Way Auto-Split:
- Postfries <3cm N25/pc -> Farmer 80% Affiliate 12% Hub 8%
- Standard >4cm N35/pc -> 80/12/8
- Juveniles >6cm N60/pc -> 80/12/8
- Growout Table Size N2,500/fish weight-based -> 80/12/8
- Ebook N10k -> Author 30% Affiliate 50% Hub 20%

## Deploy to Vercel (One Click)
1. Push this folder to GitHub
2. Go to vercel.com -> New Project -> Import GitHub repo
3. Add Env Vars: PAYSTACK_SECRET_KEY, NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY, HUB_OPAY_ACCOUNT=9161418039
4. Deploy
5. In Paystack Dashboard (Agricsquareservices@gmail.com) -> Settings -> Webhooks -> Add https://your-vercel-url.vercel.app/api/paystack/webhook -> Select charge.success
6. In Paystack Dashboard -> Settings -> Bank Accounts -> Set settlement to Opay 999992 9161418039
7. Done - Payments split instantly to Opay 9161418039

## Endpoints
- POST /api/paystack/webhook - Paystack webhook (auto-creates order)
- POST /api/paystack/initialize - Initialize payment with split_code
- GET /api/paystack/splits - List split codes
- Portal: / (unified portal HTML)